/** Automatically generated file. DO NOT MODIFY */
package com.example.robot;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}